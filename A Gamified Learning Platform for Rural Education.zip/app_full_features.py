from flask import Flask, render_template, request, redirect, session, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import date, datetime
import json, os, subprocess, tempfile, shutil, re

app = Flask(__name__, template_folder="frontend/templates", static_folder="frontend/static")
app.secret_key = "rural-learning-demo-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///learning.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

LANGUAGES = ["Python", "Java", "C", "C++", "JavaScript"]
TOPICS = {
    "Python": ["Variables", "Conditions", "Loops", "Functions", "Lists"],
    "Java": ["Variables", "Conditions", "Loops", "Classes", "Methods"],
    "C": ["Variables", "Conditions", "Loops", "Functions", "Arrays"],
    "C++": ["Variables", "Conditions", "Loops", "Classes", "STL"],
    "JavaScript": ["Variables", "Conditions", "Loops", "Functions", "Arrays"],
}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    xp = db.Column(db.Integer, default=0)
    streak = db.Column(db.Integer, default=1)

class Progress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    language = db.Column(db.String(50), nullable=False)
    topic = db.Column(db.String(100), nullable=False)
    score = db.Column(db.Float, default=0)
    attempts = db.Column(db.Integer, default=0)
    last_date = db.Column(db.String(20), default="")

class CodingProblem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    slug = db.Column(db.String(160), unique=True, nullable=False)
    language = db.Column(db.String(30), nullable=False, default="Python")
    title = db.Column(db.String(200), nullable=False)
    difficulty = db.Column(db.String(20), nullable=False)
    description = db.Column(db.Text, nullable=False)
    function_name = db.Column(db.String(100), nullable=False, default="solution")
    starter_code = db.Column(db.Text, nullable=False)
    solution_code = db.Column(db.Text, nullable=False, default="")
    examples_json = db.Column(db.Text, nullable=False, default="[]")
    tests_json = db.Column(db.Text, nullable=False, default="[]")
    constraints_json = db.Column(db.Text, nullable=False, default="[]")

class CodingSubmission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    problem_id = db.Column(db.Integer, db.ForeignKey("coding_problem.id"), nullable=False)
    language = db.Column(db.String(30), nullable=False, default="Python")
    code = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(60), nullable=False)
    error_message = db.Column(db.Text, default="")
    solution_shown = db.Column(db.Boolean, default=False)
    runtime_ms = db.Column(db.Float, default=0)
    passed_tests = db.Column(db.Integer, default=0)
    total_tests = db.Column(db.Integer, default=0)
    created_at = db.Column(db.String(30), nullable=False, default="")


def q(question, options, answer, explanation):
    return {"question": question, "options": options, "answer": answer, "explanation": explanation}

# Exactly 15 questions per language.
QUIZZES = {
"Python": [
 q("Which symbol assigns a value to a variable?", ["=", "==", ":=", "=>"], "=", "Python uses = for assignment."),
 q("What type is 25?", ["str", "int", "float", "bool"], "int", "Whole numbers without a decimal are int."),
 q("Which is a valid variable name?", ["2name", "my_name", "my-name", "class"], "my_name", "Identifiers can contain letters and underscores and cannot start with a digit."),
 q("Which keyword starts a condition?", ["if", "for", "def", "when"], "if", "Python uses if to test a condition."),
 q("Which operator checks equality?", ["=", "==", "!=", "=>"], "==", "== compares two values."),
 q("Which keyword represents the logical AND operation?", ["and", "&&", "AND", "with"], "and", "Python uses the word and for logical conjunction."),
 q("Which loop is commonly used to iterate over a list?", ["for", "if", "switch", "case"], "for", "for iterates through items in an iterable."),
 q("Which keyword exits a loop early?", ["stop", "break", "exitloop", "end"], "break", "break immediately exits the nearest loop."),
 q("Which keyword skips to the next loop iteration?", ["skip", "continue", "next", "pass"], "continue", "continue skips the remaining body and starts the next iteration."),
 q("Which keyword defines a function?", ["func", "function", "def", "define"], "def", "Python function definitions begin with def."),
 q("Which keyword returns a value from a function?", ["send", "return", "yieldback", "give"], "return", "return sends a value back to the caller."),
 q("Which brackets create a list?", ["()", "[]", "{}", "<>"], "[]", "Square brackets create Python lists."),
 q("What is the first index of a list?", ["0", "1", "-1", "2"], "0", "Python sequences use zero-based indexing."),
 q("Which method adds one item to a list?", ["add()", "append()", "push()", "insertLast()"], "append()", "append() adds one item at the end of a list."),
 q("Which value represents no value in Python?", ["null", "None", "nil", "empty"], "None", "None is Python's null-like singleton value."),
],
"Java": [
 q("Which keyword declares an integer variable?", ["int", "integer", "num", "whole"], "int", "int is Java's primitive integer type."),
 q("Which type stores true or false?", ["boolean", "bool", "bit", "truth"], "boolean", "Java uses boolean for true/false values."),
 q("Which keyword creates an object?", ["new", "make", "create", "object"], "new", "new allocates an object and invokes a constructor."),
 q("Which keyword starts a condition?", ["if", "when", "check", "condition"], "if", "if begins a conditional statement."),
 q("Which operator checks equality of primitive values?", ["=", "==", "===", "equals"], "==", "== compares primitive values in Java."),
 q("Which keyword handles the alternative branch?", ["else", "otherwise", "elif", "default"], "else", "else provides the alternative branch of an if statement."),
 q("Which loop is useful for a known number of iterations?", ["for", "if", "switch", "try"], "for", "A for loop is commonly used for counted iteration."),
 q("Which keyword exits a loop?", ["stop", "break", "exit", "leave"], "break", "break exits the nearest loop or switch."),
 q("Which keyword skips to the next loop iteration?", ["skip", "continue", "next", "pass"], "continue", "continue moves to the next iteration."),
 q("Which keyword declares a class?", ["class", "struct", "type", "object"], "class", "Java class declarations use class."),
 q("A Java method is normally declared inside a...", ["class", "loop", "comment", "array"], "class", "Methods belong to classes."),
 q("Which keyword returns a value from a method?", ["send", "return", "back", "yield"], "return", "return exits a method and can provide a value."),
 q("Which collection stores an ordered resizable list?", ["ArrayList", "HashKey", "VectorOnly", "Tuple"], "ArrayList", "ArrayList is a resizable ordered list implementation."),
 q("Which access modifier allows access from anywhere?", ["private", "public", "local", "internal"], "public", "public members are accessible wherever the class is visible."),
 q("Which method is the Java program entry point?", ["start()", "main()", "run()", "begin()"], "main()", "The conventional entry point is public static void main(String[] args)."),
],
"C": [
 q("Which type stores an integer?", ["int", "integer", "number", "whole"], "int", "int is the standard integer type in C."),
 q("Which symbol ends most C statements?", [".", ",", ";", ":"], ";", "Most C statements end with a semicolon."),
 q("Which format specifier is used for int in printf?", ["%d", "%s", "%f", "%c"], "%d", "%d prints an integer."),
 q("Which keyword starts a condition?", ["if", "when", "check", "condition"], "if", "if begins a conditional statement."),
 q("Which operator checks equality?", ["=", "==", "===", "equals"], "==", "== compares values; = assigns."),
 q("Which keyword provides the alternative branch?", ["else", "otherwise", "elif", "default"], "else", "else is used for the alternative branch."),
 q("Which loop is useful when the number of iterations is known?", ["for", "if", "switch", "case"], "for", "for is commonly used for counted loops."),
 q("Which keyword exits a loop?", ["stop", "break", "exit", "quit"], "break", "break exits the nearest loop."),
 q("Which keyword skips to the next iteration?", ["skip", "continue", "next", "pass"], "continue", "continue skips to the next iteration."),
 q("Which keyword means a function returns no value?", ["null", "void", "none", "empty"], "void", "void indicates no return value."),
 q("Which header provides printf?", ["stdio.h", "stdlib.h", "string.h", "math.h"], "stdio.h", "printf is declared in stdio.h."),
 q("Which function is the usual C program entry point?", ["start", "main", "run", "begin"], "main", "Execution begins in main()."),
 q("C arrays use which first index?", ["0", "1", "-1", "depends"], "0", "C arrays are zero-indexed."),
 q("Which brackets declare an array?", ["()", "[]", "{}", "<>"], "[]", "Array declarations use square brackets."),
 q("Which operator gets the address of a variable?", ["*", "&", "#", "@"], "&", "The unary & operator produces an object's address."),
],
"C++": [
 q("Which type stores an integer?", ["int", "integer", "number", "whole"], "int", "int is a built-in integer type."),
 q("Which symbol ends most C++ statements?", [".", ",", ";", ":"], ";", "Most statements end with a semicolon."),
 q("Which header provides std::vector?", ["<vector>", "<array>", "<listonly>", "<maponly>"], "<vector>", "std::vector is declared in the vector header."),
 q("Which keyword starts a condition?", ["if", "when", "check", "condition"], "if", "if begins a conditional statement."),
 q("Which operator checks equality?", ["=", "==", "===", "equals"], "==", "== compares values."),
 q("Which keyword handles the alternative branch?", ["else", "otherwise", "elif", "default"], "else", "else is the alternative branch."),
 q("Which loop is commonly used for iteration?", ["for", "if", "class", "switch"], "for", "for is a common iteration construct."),
 q("Which keyword exits a loop?", ["stop", "break", "exit", "quit"], "break", "break exits the nearest loop."),
 q("Which keyword skips to the next iteration?", ["skip", "continue", "next", "pass"], "continue", "continue skips the remaining body."),
 q("Which keyword defines a class?", ["class", "object", "define", "structonly"], "class", "class introduces a class definition."),
 q("Which access specifier exposes members publicly?", ["public", "open", "visible", "shared"], "public", "public members are accessible to callers."),
 q("Which object represents standard output?", ["std::cout", "std::print", "console", "stdoutOnly"], "std::cout", "std::cout is the standard output stream."),
 q("Which operator is used for scope resolution?", ["::", "->", ".", "##"], "::", "The scope resolution operator is ::."),
 q("Which keyword creates an object dynamically?", ["new", "make", "alloc", "create"], "new", "new dynamically allocates an object."),
 q("Which container stores key-value pairs?", ["map", "vector", "stack", "queue"], "map", "std::map stores key-value pairs."),
],
"JavaScript": [
 q("Which keyword can declare a block-scoped variable?", ["let", "integer", "define", "make"], "let", "let declares a block-scoped variable."),
 q("Which keyword declares a constant?", ["const", "constant", "fixed", "final"], "const", "const creates a binding that cannot be reassigned."),
 q("What type is 10 in JavaScript?", ["number", "int", "float", "integer"], "number", "JavaScript uses the Number type for ordinary numeric values."),
 q("Which keyword starts a condition?", ["if", "when", "check", "condition"], "if", "if begins a conditional statement."),
 q("Which operator checks strict equality?", ["=", "==", "===", "!=="], "===", "=== checks equality without type coercion."),
 q("Which keyword provides the alternative branch?", ["else", "otherwise", "elif", "default"], "else", "else handles the alternative branch."),
 q("Which keyword starts a counting loop?", ["for", "if", "function", "class"], "for", "for is commonly used for counted iteration."),
 q("Which keyword exits a loop?", ["stop", "break", "exit", "quit"], "break", "break exits the nearest loop."),
 q("Which keyword skips to the next iteration?", ["skip", "continue", "next", "pass"], "continue", "continue skips to the next iteration."),
 q("Which keyword declares a function?", ["function", "def", "func", "method"], "function", "function declares a traditional JavaScript function."),
 q("Which keyword returns a value from a function?", ["return", "send", "back", "yield"], "return", "return sends a value back to the caller."),
 q("Which brackets create an array?", ["()", "[]", "{}", "<>"], "[]", "Square brackets create JavaScript arrays."),
 q("What is the first array index?", ["0", "1", "-1", "2"], "0", "JavaScript arrays are zero-indexed."),
 q("Which method adds an item to the end of an array?", ["append()", "push()", "add()", "insertEnd()"], "push()", "push() appends one or more values."),
 q("Which value represents an explicitly empty value?", ["undefined", "null", "empty", "none"], "null", "null is an explicit intentional absence of an object/value."),
],
}

# Language-specific coding exercises. Each has a solution and tests.
CODING = [
 {"language":"Python","slug":"py-sum-two","title":"Sum Two Numbers","difficulty":"Easy","description":"Write a function that returns the sum of two integers.","function_name":"sum_two","starter":"def sum_two(a, b):\n    # return the sum\n    pass","solution":"def sum_two(a, b):\n    return a + b","tests":[{"args":[2,3],"expected":5},{"args":[-2,5],"expected":3},{"args":[10,0],"expected":10}],"examples":["sum_two(2, 3) -> 5"]},
 {"language":"Python","slug":"py-reverse","title":"Reverse a String","difficulty":"Easy","description":"Return the input string in reverse order.","function_name":"reverse_string","starter":"def reverse_string(s):\n    pass","solution":"def reverse_string(s):\n    return s[::-1]","tests":[{"args":["hello"],"expected":"olleh"},{"args":["Python"],"expected":"nohtyP"}],"examples":["reverse_string('hello') -> 'olleh'"]},
 {"language":"Python","slug":"py-even-count","title":"Count Even Numbers","difficulty":"Easy","description":"Return how many numbers in the list are even.","function_name":"count_even","starter":"def count_even(nums):\n    pass","solution":"def count_even(nums):\n    return sum(1 for n in nums if n % 2 == 0)","tests":[{"args":[[1,2,3,4]],"expected":2},{"args":[[2,2,2]],"expected":3}],"examples":["count_even([1,2,3,4]) -> 2"]},
 {"language":"Java","slug":"java-sum-two","title":"Sum Two Numbers","difficulty":"Easy","description":"Complete the method so it returns a + b.","function_name":"sumTwo","starter":"public static int sumTwo(int a, int b) {\n    // return a + b\n    return 0;\n}","solution":"public static int sumTwo(int a, int b) {\n    return a + b;\n}","tests":[],"examples":["sumTwo(2, 3) -> 5"]},
 {"language":"Java","slug":"java-even","title":"Check Even Number","difficulty":"Easy","description":"Return true when n is even.","function_name":"isEven","starter":"public static boolean isEven(int n) {\n    return false;\n}","solution":"public static boolean isEven(int n) {\n    return n % 2 == 0;\n}","tests":[],"examples":["isEven(8) -> true"]},
 {"language":"Java","slug":"java-max","title":"Maximum of Two","difficulty":"Easy","description":"Return the larger of a and b.","function_name":"maxTwo","starter":"public static int maxTwo(int a, int b) {\n    return 0;\n}","solution":"public static int maxTwo(int a, int b) {\n    return Math.max(a, b);\n}","tests":[],"examples":["maxTwo(8, 5) -> 8"]},
 {"language":"C","slug":"c-sum-two","title":"Sum Two Numbers","difficulty":"Easy","description":"Write a function that returns a + b.","function_name":"sum_two","starter":"int sum_two(int a, int b) {\n    return 0;\n}","solution":"int sum_two(int a, int b) {\n    return a + b;\n}","tests":[],"examples":["sum_two(2, 3) -> 5"]},
 {"language":"C","slug":"c-even","title":"Check Even Number","difficulty":"Easy","description":"Return 1 when n is even, otherwise 0.","function_name":"is_even","starter":"int is_even(int n) {\n    return 0;\n}","solution":"int is_even(int n) {\n    return n % 2 == 0;\n}","tests":[],"examples":["is_even(8) -> 1"]},
 {"language":"C","slug":"c-max","title":"Maximum of Two","difficulty":"Easy","description":"Return the larger of a and b.","function_name":"max_two","starter":"int max_two(int a, int b) {\n    return 0;\n}","solution":"int max_two(int a, int b) {\n    return a > b ? a : b;\n}","tests":[],"examples":["max_two(8, 5) -> 8"]},
 {"language":"C++","slug":"cpp-sum-two","title":"Sum Two Numbers","difficulty":"Easy","description":"Write a function that returns a + b.","function_name":"sumTwo","starter":"int sumTwo(int a, int b) {\n    return 0;\n}","solution":"int sumTwo(int a, int b) {\n    return a + b;\n}","tests":[],"examples":["sumTwo(2, 3) -> 5"]},
 {"language":"C++","slug":"cpp-even","title":"Check Even Number","difficulty":"Easy","description":"Return true when n is even.","function_name":"isEven","starter":"bool isEven(int n) {\n    return false;\n}","solution":"bool isEven(int n) {\n    return n % 2 == 0;\n}","tests":[],"examples":["isEven(8) -> true"]},
 {"language":"C++","slug":"cpp-max","title":"Maximum of Two","difficulty":"Easy","description":"Return the larger of a and b.","function_name":"maxTwo","starter":"int maxTwo(int a, int b) {\n    return 0;\n}","solution":"int maxTwo(int a, int b) {\n    return std::max(a, b);\n}","tests":[],"examples":["maxTwo(8, 5) -> 8"]},
 {"language":"JavaScript","slug":"js-sum-two","title":"Sum Two Numbers","difficulty":"Easy","description":"Write a function that returns a + b.","function_name":"sumTwo","starter":"function sumTwo(a, b) {\n    return 0;\n}","solution":"function sumTwo(a, b) {\n    return a + b;\n}","tests":[{"args":[2,3],"expected":5},{"args":[-2,5],"expected":3}],"examples":["sumTwo(2, 3) -> 5"]},
 {"language":"JavaScript","slug":"js-reverse","title":"Reverse a String","difficulty":"Easy","description":"Return the string reversed.","function_name":"reverseString","starter":"function reverseString(s) {\n    return s;\n}","solution":"function reverseString(s) {\n    return s.split('').reverse().join('');\n}","tests":[{"args":["hello"],"expected":"olleh"}],"examples":["reverseString('hello') -> 'olleh'"]},
 {"language":"JavaScript","slug":"js-even","title":"Check Even Number","difficulty":"Easy","description":"Return true when n is even.","function_name":"isEven","starter":"function isEven(n) {\n    return false;\n}","solution":"function isEven(n) {\n    return n % 2 === 0;\n}","tests":[{"args":[8],"expected":True},{"args":[7],"expected":False}],"examples":["isEven(8) -> true"]},
]


def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def login_required():
    return current_user() is not None

def safe_json(s):
    try: return json.loads(s)
    except Exception: return []


def migrate_db():
    """Add new columns to an older learning.db without deleting existing users/data."""
    inspector = db.inspect(db.engine)
    tables = inspector.get_table_names()
    if "coding_problem" in tables:
        cols = {c["name"] for c in inspector.get_columns("coding_problem")}
        additions = {
            "language": "VARCHAR(30) DEFAULT 'Python'",
            "solution_code": "TEXT DEFAULT ''",
            "tests_json": "TEXT DEFAULT '[]'",
        }
        for name, typ in additions.items():
            if name not in cols:
                db.session.execute(db.text(f"ALTER TABLE coding_problem ADD COLUMN {name} {typ}"))
        db.session.commit()
    if "coding_submission" in tables:
        cols = {c["name"] for c in inspector.get_columns("coding_submission")}
        additions = {
            "error_message": "TEXT DEFAULT ''",
            "solution_shown": "INTEGER DEFAULT 0",
        }
        for name, typ in additions.items():
            if name not in cols:
                db.session.execute(db.text(f"ALTER TABLE coding_submission ADD COLUMN {name} {typ}"))
        db.session.commit()


def seed_data():
    for item in CODING:
        p = CodingProblem.query.filter_by(slug=item["slug"]).first()
        if not p:
            p = CodingProblem(slug=item["slug"], language=item["language"], title=item["title"], difficulty=item["difficulty"], description=item["description"], function_name=item["function_name"], starter_code=item["starter"], solution_code=item["solution"], examples_json=json.dumps(item["examples"]), tests_json=json.dumps(item["tests"]), constraints_json=json.dumps([]))
            db.session.add(p)
        else:
            p.language=item["language"]; p.solution_code=item["solution"]; p.tests_json=json.dumps(item["tests"]); p.function_name=item["function_name"]; p.starter_code=item["starter"]
    db.session.commit()


def run_python(code, function_name, tests):
    with tempfile.TemporaryDirectory() as td:
        runner = os.path.join(td, "runner.py")
        payload = repr(tests)
        script = f'''import json, traceback\ntry:\n ns={{}}\n exec({code!r}, ns)\n fn=ns.get({function_name!r})\n if not callable(fn): raise Exception("Function {function_name} was not found")\n out=[]\n for t in {payload}:\n  actual=fn(*t.get("args",[]))\n  out.append({{"passed":actual==t.get("expected"),"expected":t.get("expected"),"actual":actual}})\n print(json.dumps({{"ok":True,"results":out}}))\nexcept Exception as e:\n print(json.dumps({{"ok":False,"error":str(e),"traceback":traceback.format_exc()}}))'''
        open(runner,"w",encoding="utf-8").write(script)
        try:
            r=subprocess.run(["python",runner],capture_output=True,text=True,timeout=3,cwd=td)
        except subprocess.TimeoutExpired:
            return {"status":"Time Limit Exceeded","passed":0,"total":len(tests),"error":"Your program took too long to finish."}
        if r.returncode != 0:
            return {"status":"Runtime Error","passed":0,"total":len(tests),"error":r.stderr}
        try: out=json.loads(r.stdout.strip())
        except Exception: return {"status":"Runtime Error","passed":0,"total":len(tests),"error":r.stdout or r.stderr}
        if not out.get("ok"):
            return {"status":"Runtime Error","passed":0,"total":len(tests),"error":out.get("error","Unknown error"),"traceback":out.get("traceback","")}
        results=out["results"]; passed=sum(x["passed"] for x in results)
        return {"status":"Accepted" if passed==len(tests) else "Wrong Answer","passed":passed,"total":len(tests),"details":results,"error":""}


def run_javascript(code, function_name, tests):
    node=shutil.which("node")
    if not node: return {"status":"Compiler/Runtime Not Found","passed":0,"total":len(tests),"error":"Node.js is not installed or not available in PATH."}
    with tempfile.TemporaryDirectory() as td:
        path=os.path.join(td,"runner.js")
        test_json=json.dumps(tests)
        script=f'''try {{\n{code}\nconst tests={test_json};\nconst fn=typeof {function_name} === 'function' ? {function_name} : null;\nif(!fn) throw new Error("Function {function_name} was not found");\nlet results=[];\nfor(const t of tests) {{ const actual=fn(...t.args); results.push({{passed: JSON.stringify(actual)===JSON.stringify(t.expected), expected:t.expected, actual}}); }}\nconsole.log(JSON.stringify({{ok:true,results}}));\n}} catch(e) {{ console.log(JSON.stringify({{ok:false,error:e.toString()}})); }}'''
        open(path,"w",encoding="utf-8").write(script)
        try:r=subprocess.run([node,path],capture_output=True,text=True,timeout=3,cwd=td)
        except subprocess.TimeoutExpired:return {"status":"Time Limit Exceeded","passed":0,"total":len(tests),"error":"Your program took too long to finish."}
        try:o=json.loads(r.stdout.strip())
        except Exception:return {"status":"Runtime Error","passed":0,"total":len(tests),"error":r.stderr or r.stdout}
        if not o.get("ok"):return {"status":"Runtime Error","passed":0,"total":len(tests),"error":o.get("error","Unknown error")}
        res=o["results"]; passed=sum(x["passed"] for x in res)
        return {"status":"Accepted" if passed==len(tests) else "Wrong Answer","passed":passed,"total":len(tests),"details":res,"error":""}


def run_compiled(code, language, slug):
    """Compile and execute the small language exercises with a generated test harness."""
    if language == "Java":
        javac, java = shutil.which("javac"), shutil.which("java")
        if not javac or not java:
            return {"status":"Compiler Not Found","passed":0,"total":0,"error":"Java JDK (javac/java) is not installed or not available in PATH."}
        calls = {
            "java-sum-two": "System.out.println(sumTwo(2,3)); System.out.println(sumTwo(-2,5));",
            "java-even": "System.out.println(isEven(8)); System.out.println(isEven(7));",
            "java-max": "System.out.println(maxTwo(8,5)); System.out.println(maxTwo(-2,-7));",
        }
        expected = {"java-sum-two":["5","3"],"java-even":["true","false"],"java-max":["8","-2"]}
        return _compile_and_run_java(code, calls.get(slug,""), expected.get(slug,[]), javac, java)
    if language in ("C", "C++"):
        compiler = shutil.which("g++" if language=="C++" else "gcc")
        if not compiler:
            return {"status":"Compiler Not Found","passed":0,"total":0,"error":f"{language} compiler is not installed or not available in PATH."}
        calls = {
            "c-sum-two": "printf(\"%d\\n\", sum_two(2,3)); printf(\"%d\\n\", sum_two(-2,5));",
            "c-even": "printf(\"%d\\n\", is_even(8)); printf(\"%d\\n\", is_even(7));",
            "c-max": "printf(\"%d\\n\", max_two(8,5)); printf(\"%d\\n\", max_two(-2,-7));",
            "cpp-sum-two": "std::cout << sumTwo(2,3) << std::endl; std::cout << sumTwo(-2,5) << std::endl;",
            "cpp-even": "std::cout << (isEven(8) ? \"1\" : \"0\") << std::endl; std::cout << (isEven(7) ? \"1\" : \"0\") << std::endl;",
            "cpp-max": "std::cout << maxTwo(8,5) << std::endl; std::cout << maxTwo(-2,-7) << std::endl;",
        }
        expected = {
            "c-sum-two":["5","3"],"c-even":["1","0"],"c-max":["8","-2"],
            "cpp-sum-two":["5","3"],"cpp-even":["1","0"],"cpp-max":["8","-2"]
        }
        return _compile_and_run_c_family(code, language, calls.get(slug,""), expected.get(slug,[]), compiler)
    return {"status":"Unsupported","passed":0,"total":0,"error":"This language is not supported by the local runner."}


def _compile_and_run_java(code, calls, expected, javac, java):
    with tempfile.TemporaryDirectory() as td:
        src=os.path.join(td,"Main.java")
        open(src,"w",encoding="utf-8").write("public class Main {\n"+code+"\npublic static void main(String[] args){"+calls+"}\n}")
        c=subprocess.run([javac,src],capture_output=True,text=True,timeout=5,cwd=td)
        if c.returncode!=0:
            return {"status":"Compile Error","passed":0,"total":len(expected),"error":c.stderr or c.stdout}
        r=subprocess.run([java,"-cp",td,"Main"],capture_output=True,text=True,timeout=3,cwd=td)
        if r.returncode!=0:
            return {"status":"Runtime Error","passed":0,"total":len(expected),"error":r.stderr or r.stdout}
        got=[x.strip() for x in r.stdout.splitlines() if x.strip()!=""]
        passed=sum(1 for a,b in zip(got,expected) if a==b)
        return {"status":"Accepted" if passed==len(expected) and len(got)==len(expected) else "Wrong Answer","passed":passed,"total":len(expected),"details":[{"expected":b,"actual":a,"passed":a==b} for a,b in zip(got,expected)],"error":""}


def _compile_and_run_c_family(code, language, calls, expected, compiler):
    with tempfile.TemporaryDirectory() as td:
        ext="cpp" if language=="C++" else "c"
        src=os.path.join(td,"main."+ext); exe=os.path.join(td,"program.exe" if os.name=="nt" else "program")
        includes="#include <iostream>\n#include <algorithm>\nusing namespace std;\n" if language=="C++" else "#include <stdio.h>\n"
        open(src,"w",encoding="utf-8").write(includes+"\n"+code+"\nint main(){"+calls+" return 0; }\n")
        c=subprocess.run([compiler,src,"-o",exe],capture_output=True,text=True,timeout=5,cwd=td)
        if c.returncode!=0:
            return {"status":"Compile Error","passed":0,"total":len(expected),"error":c.stderr or c.stdout}
        r=subprocess.run([exe],capture_output=True,text=True,timeout=3,cwd=td)
        if r.returncode!=0:
            return {"status":"Runtime Error","passed":0,"total":len(expected),"error":r.stderr or r.stdout}
        got=[x.strip() for x in r.stdout.splitlines() if x.strip()!=""]
        passed=sum(1 for a,b in zip(got,expected) if a==b)
        return {"status":"Accepted" if passed==len(expected) and len(got)==len(expected) else "Wrong Answer","passed":passed,"total":len(expected),"details":[{"expected":b,"actual":a,"passed":a==b} for a,b in zip(got,expected)],"error":""}

def execute_problem(problem, code):
    tests=safe_json(problem.tests_json)
    if problem.language=="Python": return run_python(code, problem.function_name, tests)
    if problem.language=="JavaScript": return run_javascript(code, problem.function_name, tests)
    return run_compiled(code, problem.language, problem.slug)

@app.route("/")
def index(): return render_template("index.html", languages=LANGUAGES)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
        if not name or not email or not password:return render_template("register.html",error="All fields are required.")
        if User.query.filter_by(email=email).first():return render_template("register.html",error="Email already registered.")
        u=User(name=name,email=email,password=password,xp=0,streak=1);db.session.add(u);db.session.commit();return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
        u=User.query.filter_by(email=email,password=password).first()
        if not u:return render_template("login.html",error="Invalid email or password.")
        session["user_id"]=u.id;return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():session.clear();return redirect(url_for("index"))

@app.route("/profile", methods=["GET","POST"])
def profile():
    if not login_required():return redirect(url_for("login"))
    u=current_user()
    if request.method=="POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower()
        if not name or not email:return render_template("profile.html",user=u,error="Name and email are required.")
        other=User.query.filter(User.email==email,User.id!=u.id).first()
        if other:return render_template("profile.html",user=u,error="That email is already used.")
        u.name=name;u.email=email;db.session.commit();flash("Profile updated successfully.","success");return redirect(url_for("profile"))
    progress=Progress.query.filter_by(user_id=u.id).order_by(Progress.id.desc()).all()
    submissions=CodingSubmission.query.filter_by(user_id=u.id).order_by(CodingSubmission.id.desc()).limit(10).all()
    return render_template("profile.html",user=u,progress=progress,submissions=submissions)

@app.route("/dashboard")
def dashboard():
    if not login_required():return redirect(url_for("login"))
    u=current_user(); progress=Progress.query.filter_by(user_id=u.id).all(); level=u.xp//100+1
    badges=[]
    if u.xp>=100:badges.append("100 XP")
    if any((p.attempts or 0)>=5 for p in progress):badges.append("Quiz Regular")
    if len(progress)>=3:badges.append("Active Learner")
    return render_template("dashboard.html",user=u,progress=progress,level=level,badges=badges,recommendation="Practice Coding")

@app.route("/learn/<language>")
def learn(language):
    if language not in LANGUAGES:return redirect(url_for("dashboard"))
    return render_template("learn.html",language=language,topics=TOPICS[language])

@app.route("/quiz/<language>/<topic>", methods=["GET","POST"])
def quiz(language,topic):
    if not login_required():return redirect(url_for("login"))
    if language not in QUIZZES:return redirect(url_for("dashboard"))
    questions=QUIZZES[language]
    key=f"quiz_{language}"
    if request.args.get("restart")=="1" or session.get("quiz_language")!=language:
        session["quiz_language"]=language;session["quiz_topic"]=topic;session["quiz_index"]=0;session["quiz_score"]=0;session["quiz_answers"]=[]
    if request.method=="POST":
        idx=int(session.get("quiz_index",0)); ans=request.form.get("answer","")
        if 0<=idx<len(questions):
            if ans==questions[idx]["answer"]:session["quiz_score"]=int(session.get("quiz_score",0))+1
            session["quiz_answers"] = session.get("quiz_answers",[]) + [ans]
        idx += 1; session["quiz_index"]=idx
        if idx>=len(questions):
            score=int(session.get("quiz_score",0)); pct=round(score/len(questions)*100)
            u=current_user(); p=Progress.query.filter_by(user_id=u.id,language=language,topic=topic).first()
            if not p:p=Progress(user_id=u.id,language=language,topic=topic);db.session.add(p)
            p.score=pct;p.attempts=(p.attempts or 0)+1;p.last_date=str(date.today());u.xp += score*2+10;db.session.commit()
            return render_template("result.html",score=score,total=len(questions),percentage=pct,language=language,topic=topic,correct_answers=questions)
        return redirect(url_for("quiz",language=language,topic=topic,q=idx))
    idx=int(request.args.get("q",session.get("quiz_index",0)))
    idx=max(0,min(idx,len(questions)-1));session["quiz_index"]=idx
    item=questions[idx]
    return render_template("quiz.html",language=language,topic=topic,question=item["question"],options=item["options"],question_number=idx+1,total_questions=len(questions),progress_percent=int((idx/len(questions))*100),explanation=item["explanation"])

@app.route("/coding")
def coding():
    if not login_required():return redirect(url_for("login"))
    lang=request.args.get("language","").strip()
    difficulty=request.args.get("difficulty","").strip()
    query=request.args.get("search","").strip().lower()
    problems=CodingProblem.query.order_by(CodingProblem.id.asc()).all()
    if lang:problems=[p for p in problems if p.language==lang]
    if difficulty:problems=[p for p in problems if p.difficulty==difficulty]
    if query:problems=[p for p in problems if query in p.title.lower() or query in p.description.lower()]
    return render_template("coding.html",problems=problems,languages=LANGUAGES,selected_language=lang,selected_difficulty=difficulty,search=query)

@app.route("/coding/<slug>")
def coding_problem(slug):
    if not login_required():return redirect(url_for("login"))
    p=CodingProblem.query.filter_by(slug=slug).first_or_404()
    return render_template("coding_problem.html",problem=p,examples=safe_json(p.examples_json),result=None,code=p.starter_code)

@app.route("/coding/<slug>/run",methods=["POST"])
def coding_run(slug):
    if not login_required():return redirect(url_for("login"))
    p=CodingProblem.query.filter_by(slug=slug).first_or_404(); code=request.form.get("code",p.starter_code)
    result=execute_problem(p,code)
    return render_template("coding_problem.html",problem=p,examples=safe_json(p.examples_json),result=result,code=code,show_solution=(result["status"]!="Accepted"),solution=p.solution_code)

@app.route("/coding/<slug>/submit",methods=["POST"])
def coding_submit(slug):
    if not login_required():return redirect(url_for("login"))
    u=current_user();p=CodingProblem.query.filter_by(slug=slug).first_or_404();code=request.form.get("code",p.starter_code);result=execute_problem(p,code)
    sub=CodingSubmission(user_id=u.id,problem_id=p.id,language=p.language,code=code,status=result["status"],error_message=result.get("error",""),solution_shown=result["status"]!="Accepted",runtime_ms=0,passed_tests=result.get("passed",0),total_tests=result.get("total",0),created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"));db.session.add(sub)
    if result["status"]=="Accepted":u.xp+=25
    db.session.commit()
    return render_template("coding_problem.html",problem=p,examples=safe_json(p.examples_json),result=result,code=code,show_solution=result["status"]!="Accepted",solution=p.solution_code)

@app.route("/coding/submissions")
def coding_submissions():
    if not login_required():return redirect(url_for("login"))
    u=current_user();subs=CodingSubmission.query.filter_by(user_id=u.id).order_by(CodingSubmission.id.desc()).all()
    problems={p.id:p for p in CodingProblem.query.all()}
    return render_template("coding_submissions.html",submissions=subs,problems=problems)

with app.app_context():
    db.create_all()
    migrate_db()
    seed_data()
    # Repair old NULL values that caused the quiz crash.
    db.session.execute(db.text("UPDATE progress SET attempts = 0 WHERE attempts IS NULL"))
    db.session.execute(db.text("UPDATE progress SET score = 0 WHERE score IS NULL"))
    db.session.commit()

if __name__=="__main__":
    app.run(debug=True)
