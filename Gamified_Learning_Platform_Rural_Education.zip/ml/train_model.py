import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

DATA = os.path.join(os.path.dirname(__file__), "..", "data", "student_performance.csv")
MODEL = os.path.join(os.path.dirname(__file__), "learning_model.joblib")

df = pd.read_csv(DATA)
le = LabelEncoder()
df["language_code"] = le.fit_transform(df["language"])
X = df[["language_code", "quiz_score", "attempts", "study_minutes"]]
y = df["next_level"]
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)
joblib.dump({"model": model, "encoder": le}, MODEL)
print("ML model saved:", MODEL)
