import os, joblib, pandas as pd

MODEL = os.path.join(os.path.dirname(__file__), "learning_model.joblib")

def recommend(progress):
    if not progress:
        return "Python Basics"
    weakest = min(progress, key=lambda p: p.score)
    if weakest.score < 60:
        return f"Practice {weakest.language} - {weakest.topic}"
    return "Try the next topic in your strongest language"

def predict(language, quiz_score, attempts, study_minutes):
    if not os.path.exists(MODEL):
        return "Beginner"
    bundle = joblib.load(MODEL)
    code = bundle["encoder"].transform([language])[0]
    pred = bundle["model"].predict([[code, quiz_score, attempts, study_minutes]])
    return str(pred[0])
