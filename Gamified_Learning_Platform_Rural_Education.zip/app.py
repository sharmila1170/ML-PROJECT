from flask import Flask, render_template, request, redirect, session, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import date
import os, json, subprocess, tempfile, time, shutil as file_shutil

app = Flask(__name__)
app.secret_key = "rural-learning-demo-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///learning.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    xp = db.Column(db.Integer, default=0)
    streak = db.Column(db.Integer, default=1)

class Progress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    language = db.Column(db.String(50), nullable=False)
    topic = db.Column(db.String(100), nullable=False)
    score = db.Column(db.Float, default=0)
    attempts = db.Column(db.Integer, default=0)
    last_date = db.Column(db.String(20), default="")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name, email, password = request.form["name"], request.form["email"], request.form["password"]
        if User.query.filter_by(email=email).first():
            return render_template("register.html", error="Email already registered")
        user = User(name=name, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form["email"], password=request.form["password"]).first()
        if not user:
            return render_template("login.html", error="Invalid email or password")
        session["user_id"] = user.id
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session: return redirect(url_for("login"))
    user = User.query.get(session["user_id"])
    progress = Progress.query.filter_by(user_id=user.id).all()
    level = user.xp // 100 + 1
    badges = []
    if user.xp >= 100: badges.append("First 100 XP")
    if len(progress) >= 3: badges.append("Active Learner")
    recommendation = "Python Basics"
    try:
        from ml.recommender import recommend
        recommendation = recommend(progress)
    except Exception:
        pass
    return render_template("dashboard.html", user=user, progress=progress,
                           level=level, badges=badges, recommendation=recommendation)

@app.route("/learn/<language>")
def learn(language):
    topics = {
        "Python": ["Variables", "Conditions", "Loops", "Functions", "Lists"],
        "Java": ["Variables", "Conditions", "Loops", "Classes", "Methods"],
        "C": ["Variables", "Conditions", "Loops", "Functions", "Arrays"],
        "C++": ["Variables", "Conditions", "Loops", "Classes", "STL"],
        "JavaScript": ["Variables", "Conditions", "Loops", "Functions", "Arrays"]
    }
    return render_template("learn.html", language=language, topics=topics.get(language, []))

@app.route("/quiz/<language>/<topic>", methods=["GET", "POST"])
def quiz(language, topic):
    questions = {
        "Python": {
            "Variables": [("Which symbol assigns a value?", ["=", "==", "=>", ":"], "="),
            ],
            "Loops": [("Which keyword starts a loop over a sequence?", ["for", "if", "def", "class"], "for")],
        },
        "Java": {"Variables": [("Which keyword declares an integer?", ["int", "integer", "num", "varint"], "int")]},
        "C": {"Variables": [("Which type stores an integer?", ["int", "string", "floatx", "charx"], "int")]},
        "C++": {"Variables": [("Which type stores an integer?", ["int", "integer", "number", "whole"], "int")]},
        "JavaScript": {"Variables": [("Which keyword can declare a variable?", ["let", "integer", "define", "make"], "let")]}
    }
    qs = questions.get(language, {}).get(topic, [("What should you do when learning to code?", ["Practice", "Quit", "Guess", "Skip"], "Practice")])
    if request.method == "POST":
        answer = request.form.get("answer")
        score = 100 if answer == qs[0][2] else 0
        user = User.query.get(session["user_id"])
        p = Progress.query.filter_by(user_id=user.id, language=language, topic=topic).first()
        if not p: p = Progress(user_id=user.id, language=language, topic=topic); db.session.add(p)
        p.score = score; p.attempts += 1; p.last_date = str(date.today())
        user.xp += 20 if score == 100 else 5
        db.session.commit()
        return render_template("result.html", score=score, correct=qs[0][2], language=language, topic=topic)
    return render_template("quiz.html", language=language, topic=topic, question=qs[0][0], options=qs[0][1])


# ================= LeetCode-style Coding Section =================
class CodingProblem(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    slug=db.Column(db.String(120),unique=True,nullable=False)
    title=db.Column(db.String(200),nullable=False)
    difficulty=db.Column(db.String(20),nullable=False)
    description=db.Column(db.Text,nullable=False)
    examples_json=db.Column(db.Text,nullable=False,default='[]')
    constraints_json=db.Column(db.Text,nullable=False,default='[]')
    tags_json=db.Column(db.Text,nullable=False,default='[]')
    function_name=db.Column(db.String(100),nullable=False)
    starter_code=db.Column(db.Text,nullable=False)
    visible_tests_json=db.Column(db.Text,nullable=False,default='[]')
    hidden_tests_json=db.Column(db.Text,nullable=False,default='[]')

class CodingSubmission(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    user_id=db.Column(db.Integer,db.ForeignKey('user.id'),nullable=False)
    problem_id=db.Column(db.Integer,db.ForeignKey('coding_problem.id'),nullable=False)
    language=db.Column(db.String(30),nullable=False,default='Python')
    code=db.Column(db.Text,nullable=False)
    status=db.Column(db.String(40),nullable=False)
    runtime_ms=db.Column(db.Float,default=0)
    passed_tests=db.Column(db.Integer,default=0)
    total_tests=db.Column(db.Integer,default=0)
    created_at=db.Column(db.String(30),nullable=False,default='')

CODING_PROBLEMS=[
('two-sum','Two Sum','Easy','Given an array of integers nums and a target, return the indices of the two numbers that add up to target. Exactly one solution exists.','two_sum',['Array','Hash Table'],"def two_sum(nums, target):\\n    # Write your solution here\\n    pass",[{'args':[[2,7,11,15],9],'expected':[0,1]},{'args':[[3,2,4],6],'expected':[1,2]}],[{'args':[[3,3],6],'expected':[0,1]},{'args':[[1,5,8,10],13],'expected':[1,2]},{'args':[[-1,-2,-3,-4,-5],-8],'expected':[2,4]}],[{'input':'nums = [2,7,11,15], target = 9','output':'[0,1]'},{'input':'nums = [3,2,4], target = 6','output':'[1,2]'}]),
('reverse-string','Reverse String','Easy','Return the given string reversed.','reverse_string',['String'],"def reverse_string(s):\\n    # Write your solution here\\n    pass",[{'args':['hello'],'expected':'olleh'},{'args':['abc'],'expected':'cba'}],[{'args':['Python'],'expected':'nohtyP'},{'args':['a b'],'expected':'b a'},{'args':[''],'expected':''}],[{'input':'s = "hello"','output':'"olleh"'}]),
('palindrome-number','Palindrome Number','Easy','Return True if x reads the same forward and backward. Negative numbers are not palindromes.','is_palindrome',['Math'],"def is_palindrome(x):\\n    # Write your solution here\\n    pass",[{'args':[121],'expected':True},{'args':[-121],'expected':False}],[{'args':[0],'expected':True},{'args':[1221],'expected':True},{'args':[10],'expected':False}],[{'input':'x = 121','output':'True'},{'input':'x = -121','output':'False'}]),
('fizz-buzz','Fizz Buzz','Easy','Return a list from 1 through n, replacing multiples of 3 with Fizz, 5 with Buzz, and both with FizzBuzz.','fizz_buzz',['Math','String','Simulation'],"def fizz_buzz(n):\\n    # Write your solution here\\n    pass",[{'args':[5],'expected':['1','2','Fizz','4','Buzz']}],[{'args':[1],'expected':['1']},{'args':[15],'expected':['1','2','Fizz','4','Buzz','Fizz','7','8','Fizz','Buzz','11','Fizz','13','14','FizzBuzz']}],[{'input':'n = 5','output':'["1","2","Fizz","4","Buzz"]'}]),
('maximum-number','Maximum Number','Easy','Return the largest integer in a non-empty array.','max_number',['Array'],"def max_number(nums):\\n    # Write your solution here\\n    pass",[{'args':[[3,1,9,2]],'expected':9}],[{'args':[[-5,-2,-9]],'expected':-2},{'args':[[7]],'expected':7},{'args':[[0,0,0]],'expected':0}],[{'input':'nums = [3,1,9,2]','output':'9'}]),
('array-sum','Array Sum','Easy','Return the sum of all integers in nums.','array_sum',['Array','Math'],"def array_sum(nums):\\n    # Write your solution here\\n    pass",[{'args':[[1,2,3,4]],'expected':10}],[{'args':[[-1,1]],'expected':0},{'args':[[5]],'expected':5},{'args':[[10,20,30]],'expected':60}],[{'input':'nums = [1,2,3,4]','output':'10'}]),
('count-vowels','Count Vowels','Easy','Count a, e, i, o and u in a string, case-insensitively.','count_vowels',['String'],"def count_vowels(s):\\n    # Write your solution here\\n    pass",[{'args':['Hello World'],'expected':3}],[{'args':['AEIOU'],'expected':5},{'args':['xyz'],'expected':0},{'args':['Programming'],'expected':3}],[{'input':'s = "Hello World"','output':'3'}]),
('valid-anagram','Valid Anagram','Easy','Return True if t is an anagram of s.','is_anagram',['Hash Table','String','Sorting'],"def is_anagram(s, t):\\n    # Write your solution here\\n    pass",[{'args':['anagram','nagaram'],'expected':True},{'args':['rat','car'],'expected':False}],[{'args':['listen','silent'],'expected':True},{'args':['hello','hell'],'expected':False}],[{'input':'s = "anagram", t = "nagaram"','output':'True'}]),
('contains-duplicate','Contains Duplicate','Easy','Return True if any value appears at least twice in nums.','contains_duplicate',['Array','Hash Table'],"def contains_duplicate(nums):\\n    # Write your solution here\\n    pass",[{'args':[[1,2,3,1]],'expected':True},{'args':[[1,2,3,4]],'expected':False}],[{'args':[[1,1]],'expected':True},{'args':[[7]],'expected':False}],[{'input':'nums = [1,2,3,1]','output':'True'}]),
('binary-search','Binary Search','Easy','Given a sorted array nums and target, return the index of target, or -1 if absent.','binary_search',['Array','Binary Search'],"def binary_search(nums, target):\\n    # Write your solution here\\n    pass",[{'args':[[-1,0,3,5,9,12],9],'expected':4},{'args':[[-1,0,3,5,9,12],2],'expected':-1}],[{'args':[[1],1],'expected':0},{'args':[[1,2,3,4,5],5],'expected':4}],[{'input':'nums = [-1,0,3,5,9,12], target = 9','output':'4'}]),
('move-zeroes','Move Zeroes','Easy','Return nums with all zeroes moved to the end while preserving the relative order of non-zero values.','move_zeroes',['Array','Two Pointers'],"def move_zeroes(nums):\\n    # Write your solution here\\n    pass",[{'args':[[0,1,0,3,12]],'expected':[1,3,12,0,0]}],[{'args':[[0]],'expected':[0]},{'args':[[1,2,3]],'expected':[1,2,3]},{'args':[[0,0,1]],'expected':[1,0,0]}],[{'input':'nums = [0,1,0,3,12]','output':'[1,3,12,0,0]'}]),
('best-time-to-buy-and-sell-stock','Best Time to Buy and Sell Stock','Easy','Choose one day to buy and a later day to sell. Return the maximum profit.','max_profit',['Array','Dynamic Programming'],"def max_profit(prices):\\n    # Write your solution here\\n    pass",[{'args':[[7,1,5,3,6,4]],'expected':5}],[{'args':[[7,6,4,3,1]],'expected':0},{'args':[[1,2]],'expected':1},{'args':[[2,4,1]],'expected':2}],[{'input':'prices = [7,1,5,3,6,4]','output':'5'}]),
('valid-parentheses','Valid Parentheses','Easy','Return True when brackets are correctly opened, closed and nested.','is_valid',['String','Stack'],"def is_valid(s):\\n    # Write your solution here\\n    pass",[{'args':['()'],'expected':True},{'args':['([)]'],'expected':False}],[{'args':['()[]{}'],'expected':True},{'args':['{[]}'],'expected':True},{'args':['('],'expected':False}],[{'input':'s = "()"','output':'True'},{'input':'s = "([)]"','output':'False'}]),
('merge-sorted-arrays','Merge Sorted Arrays','Easy','Return one sorted array containing all elements from two sorted arrays.','merge_sorted',['Array','Two Pointers'],"def merge_sorted(nums1, nums2):\\n    # Write your solution here\\n    pass",[{'args':[[1,3,5],[2,4,6]],'expected':[1,2,3,4,5,6]}],[{'args':[[],[1]],'expected':[1]},{'args':[[1,2],[]],'expected':[1,2]},{'args':[[1,4],[2,3]],'expected':[1,2,3,4]}],[{'input':'nums1 = [1,3,5], nums2 = [2,4,6]','output':'[1,2,3,4,5,6]'}]),
('first-unique-character','First Unique Character','Easy','Return the index of the first non-repeating character, or -1 if none exists.','first_unique_char',['Hash Table','String','Counting'],"def first_unique_char(s):\\n    # Write your solution here\\n    pass",[{'args':['leetcode'],'expected':0},{'args':['loveleetcode'],'expected':2}],[{'args':['aabb'],'expected':-1},{'args':['z'],'expected':0}],[{'input':'s = "leetcode"','output':'0'}]),
('longest-common-prefix','Longest Common Prefix','Easy','Return the longest common prefix shared by all strings.','longest_common_prefix',['String'],"def longest_common_prefix(strs):\\n    # Write your solution here\\n    pass",[{'args':[['flower','flow','flight']],'expected':'fl'},{'args':[['dog','racecar','car']],'expected':''}],[{'args':[['interview','internet','internal']],'expected':'inte'},{'args':[['a']],'expected':'a'}],[{'input':'strs = ["flower","flow","flight"]','output':'"fl"'}]),
('climbing-stairs','Climbing Stairs','Easy','You can climb 1 or 2 steps at a time. Return the number of distinct ways to reach n steps.','climb_stairs',['Dynamic Programming','Math'],"def climb_stairs(n):\\n    # Write your solution here\\n    pass",[{'args':[2],'expected':2},{'args':[3],'expected':3}],[{'args':[1],'expected':1},{'args':[5],'expected':8},{'args':[10],'expected':89}],[{'input':'n = 3','output':'3'}]),
('fibonacci-number','Fibonacci Number','Easy','Return the nth Fibonacci number using F(0)=0 and F(1)=1.','fib',['Math','Dynamic Programming','Recursion'],"def fib(n):\\n    # Write your solution here\\n    pass",[{'args':[4],'expected':3},{'args':[10],'expected':55}],[{'args':[0],'expected':0},{'args':[1],'expected':1},{'args':[20],'expected':6765}],[{'input':'n = 4','output':'3'}]),
('maximum-subarray','Maximum Subarray','Medium','Find the contiguous subarray with the largest sum and return that sum.','max_subarray',['Array','Dynamic Programming'],"def max_subarray(nums):\\n    # Write your solution here\\n    pass",[{'args':[[-2,1,-3,4,-1,2,1,-5,4]],'expected':6}],[{'args':[[1]],'expected':1},{'args':[[-1,-2,-3]],'expected':-1},{'args':[[5,4,-1,7,8]],'expected':23}],[{'input':'nums = [-2,1,-3,4,-1,2,1,-5,4]','output':'6'}]),
('missing-number','Missing Number','Easy','Given n distinct numbers from [0,n], return the only missing number.','missing_number',['Array','Math','Bit Manipulation'],"def missing_number(nums):\\n    # Write your solution here\\n    pass",[{'args':[[3,0,1]],'expected':2},{'args':[[0,1]],'expected':2}],[{'args':[[9,6,4,2,3,5,7,0,1]],'expected':8},{'args':[[0]],'expected':1}],[{'input':'nums = [3,0,1]','output':'2'}])
]

def seed_coding_problems():
    for slug,title,diff,desc,fn,tags,starter,visible,hidden,examples in CODING_PROBLEMS:
        if CodingProblem.query.filter_by(slug=slug).first(): continue
        db.session.add(CodingProblem(slug=slug,title=title,difficulty=diff,description=desc,
            function_name=fn,tags_json=json.dumps(tags),starter_code=starter,
            visible_tests_json=json.dumps(visible),hidden_tests_json=json.dumps(hidden),
            examples_json=json.dumps(examples),constraints_json=json.dumps([
                'Inputs follow the examples and are valid for the problem.',
                'Aim for an efficient solution appropriate for the listed difficulty.'
            ])))
    db.session.commit()

def _run_python_function(code, function_name, tests, timeout_seconds=2):
    workdir=tempfile.mkdtemp(prefix='ruralcode_')
    try:
        solution=os.path.join(workdir,'solution.py'); runner=os.path.join(workdir,'runner.py'); data=os.path.join(workdir,'tests.json')
        open(solution,'w',encoding='utf-8').write(code); open(data,'w',encoding='utf-8').write(json.dumps(tests))
        runner_code="""import json,sys,time,traceback
solution,function_name,tests_path=sys.argv[1],sys.argv[2],sys.argv[3]
tests=json.load(open(tests_path,encoding='utf-8')); ns={}
try:
    source=open(solution,encoding='utf-8').read(); exec(compile(source,solution,'exec'),ns,ns); fn=ns.get(function_name)
    if not callable(fn): raise NameError('Required function '+repr(function_name)+' was not found.')
except Exception:
    print(json.dumps({'status':'Compilation Error','error':traceback.format_exc()})); raise SystemExit
results=[]; start=time.perf_counter()
for i,t in enumerate(tests,1):
    try:
        st=time.perf_counter(); actual=fn(*t.get('args',[]),**t.get('kwargs',{})); ms=(time.perf_counter()-st)*1000
        ok=actual==t.get('expected'); results.append({'case':i,'passed':ok,'actual':actual,'expected':t.get('expected'),'runtime_ms':round(ms,3)})
        if not ok:
            print(json.dumps({'status':'Wrong Answer','passed_tests':sum(x['passed'] for x in results),'total_tests':len(tests),'runtime_ms':round((time.perf_counter()-start)*1000,3),'results':results})); raise SystemExit
    except SystemExit: raise
    except Exception:
        print(json.dumps({'status':'Runtime Error','passed_tests':sum(x['passed'] for x in results),'total_tests':len(tests),'runtime_ms':round((time.perf_counter()-start)*1000,3),'results':results,'error':traceback.format_exc()})); raise SystemExit
print(json.dumps({'status':'Accepted','passed_tests':len(tests),'total_tests':len(tests),'runtime_ms':round((time.perf_counter()-start)*1000,3),'results':results}))"""
        open(runner,'w',encoding='utf-8').write(runner_code)
        try:
            p=subprocess.run([os.environ.get('PYTHON','python'),runner,solution,function_name,data],cwd=workdir,capture_output=True,text=True,timeout=timeout_seconds)
        except subprocess.TimeoutExpired: return {'status':'Time Limit Exceeded','passed_tests':0,'total_tests':len(tests),'runtime_ms':timeout_seconds*1000,'results':[],'error':'Execution exceeded the 2 second time limit.'}
        line=p.stdout.strip().splitlines()[-1] if p.stdout.strip() else ''
        try: result=json.loads(line)
        except Exception: result={'status':'Runtime Error','error':p.stderr[-4000:] or p.stdout[-4000:]}
        return result
    finally: file_shutil.rmtree(workdir,ignore_errors=True)

@app.route('/coding')
def coding():
    q=request.args.get('q','').strip().lower(); difficulty=request.args.get('difficulty','').strip(); tag=request.args.get('tag','').strip()
    problems=CodingProblem.query.order_by(CodingProblem.id.asc()).all()
    if q: problems=[p for p in problems if q in p.title.lower() or q in p.description.lower()]
    if difficulty: problems=[p for p in problems if p.difficulty==difficulty]
    if tag: problems=[p for p in problems if tag in json.loads(p.tags_json)]
    solved_ids=set()
    if session.get('user_id'):
        solved_ids={x.problem_id for x in CodingSubmission.query.filter_by(user_id=session['user_id'],status='Accepted').all()}
    for p in problems: p.tags=json.loads(p.tags_json)
    all_tags=sorted({t for x in CODING_PROBLEMS for t in x[5]})
    total=CodingProblem.query.count(); solved_count=0
    if session.get('user_id'): solved_count=CodingSubmission.query.filter_by(user_id=session['user_id'],status='Accepted').with_entities(CodingSubmission.problem_id).distinct().count()
    return render_template('coding.html',problems=problems,solved_slugs={p.slug for p in problems if p.id in solved_ids},all_tags=all_tags,total=total,solved_count=solved_count,q=q,difficulty=difficulty,tag=tag)

@app.route('/coding/problem/<slug>')
def coding_problem(slug):
    problem=CodingProblem.query.filter_by(slug=slug).first_or_404(); ordered=CodingProblem.query.order_by(CodingProblem.id.asc()).all(); i=ordered.index(problem)
    solved=bool(session.get('user_id') and CodingSubmission.query.filter_by(user_id=session['user_id'],problem_id=problem.id,status='Accepted').first())
    return render_template('coding_problem.html',problem=problem,examples=json.loads(problem.examples_json),constraints=json.loads(problem.constraints_json),tags=json.loads(problem.tags_json),solved=solved,previous_problem=ordered[i-1] if i else None,next_problem=ordered[i+1] if i+1<len(ordered) else None)

@app.route('/coding/problem/<slug>/run',methods=['POST'])
def coding_run(slug):
    p=CodingProblem.query.filter_by(slug=slug).first_or_404(); payload=request.get_json(silent=True) or {}; code=payload.get('code','')
    if not code.strip(): return jsonify({'status':'Runtime Error','error':'Write some code before running.'}),400
    return jsonify(_run_python_function(code,p.function_name,json.loads(p.visible_tests_json)))

@app.route('/coding/problem/<slug>/submit',methods=['POST'])
def coding_submit(slug):
    if not session.get('user_id'): return jsonify({'status':'Login Required','message':'Please log in before submitting.'}),401
    p=CodingProblem.query.filter_by(slug=slug).first_or_404(); payload=request.get_json(silent=True) or {}; code=payload.get('code','')
    if not code.strip(): return jsonify({'status':'Runtime Error','error':'Write some code before submitting.'}),400
    visible=json.loads(p.visible_tests_json); tests=visible+json.loads(p.hidden_tests_json); result=_run_python_function(code,p.function_name,tests)
    result['results']=[dict(case=r.get('case'),passed=r.get('passed'),runtime_ms=r.get('runtime_ms'),**({'actual':r.get('actual'),'expected':r.get('expected')} if r.get('case',0)<=len(visible) else {})) for r in result.get('results',[])]
    db.session.add(CodingSubmission(user_id=session['user_id'],problem_id=p.id,language='Python',code=code,status=result.get('status','Runtime Error'),runtime_ms=float(result.get('runtime_ms',0)),passed_tests=int(result.get('passed_tests',0)),total_tests=int(result.get('total_tests',len(tests))),created_at=str(date.today())))
    if result.get('status')=='Accepted' and not CodingSubmission.query.filter_by(user_id=session['user_id'],problem_id=p.id,status='Accepted').first():
        User.query.get(session['user_id']).xp += 10
    db.session.commit(); return jsonify(result)

@app.route('/coding/submissions')
def coding_submissions():
    if not session.get('user_id'): return redirect(url_for('login'))
    submissions=CodingSubmission.query.filter_by(user_id=session['user_id']).order_by(CodingSubmission.id.desc()).limit(100).all()
    problems={p.id:p for p in CodingProblem.query.all()}
    return render_template('coding_submissions.html',submissions=submissions,problems=problems)

with app.app_context():
    db.create_all()
    seed_coding_problems()

if __name__ == "__main__":
    app.run(debug=True)
